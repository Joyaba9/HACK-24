import React, { useState, useEffect } from "react";
import "./similar_product_prediction.css";
import productData from "./similar_product_data.json";

const SimilarProductPrediction = () => {
    const [category, setCategory] = useState("");
    const [subCategory, setSubCategory] = useState("");
    const [product, setProduct] = useState("");
    const [subCategories, setSubCategories] = useState([]);
    const [products, setProducts] = useState([]);

    useEffect(() => {
        if (category && productData[category]) {
            setSubCategories(Object.keys(productData[category]));
        }
    }, [category]);

    useEffect(() => {
        if (category && subCategory && productData[category][subCategory]) {
            setProducts(Object.keys(productData[category][subCategory][0]));
        }
    }, [category, subCategory]);

    return (
        <div className="similar-product-container">
            <h1>Similar Product Prediction</h1>
            <div className="input-container">
                <label htmlFor="category">Category:</label>
                <select id="category" value={category} onChange={(e) => setCategory(e.target.value)}>
                    {Object.keys(productData).map((category) => (
                        <option key={category} value={category}>
                            {category}
                        </option>
                    ))}
                </select>

                <label htmlFor="subCategory">Sub-Category:</label>
                <select id="subCategory" value={subCategory} onChange={(e) => setSubCategory(e.target.value)}>
                    {subCategories.map((subCategory) => (
                        <option key={subCategory} value={subCategory}>
                            {subCategory}
                        </option>
                    ))}
                </select>

                <label htmlFor="product">Product:</label>
                <select id="product" value={product} onChange={(e) => setProduct(e.target.value)}>
                    {products.map((product, index) => (
                        <option key={index} value={product}>
                            {product}
                        </option>
                    ))}
                </select>
            </div>
        </div>
    );
};

export default SimilarProductPrediction;